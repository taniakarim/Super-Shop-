



<!DOCTYPE html>
<html>
    <head>
        <title>Project</title>
    </head>
    <body>

        <h1>Memeber Selection</h1>
        <form method="POST" action="selectmember.php">
           
            <input type="radio" name="member" value="HRmember">member
            <input type="radio" name="member" value="HRemployee">employee <br>
            <br>
            <br>
            <input type="submit" name="submit_button"  value="Select" required>
            
        </form>
    </body>
</html>