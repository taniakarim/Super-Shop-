<html>
<head>
 
 <title> Client Home</title>

</head>

<body>

<img src="tania.png" alt="Trulli" width="400" height="120">
<div>
 <a href="login.php">Logout</a>
 </div> <br>
 <section>
  <nav>
    <ul><form><br>
      <div>
      <input  type="search" placeholder="Search-Product" >
      <button  type="submit">Search-Product</button>
	  </div>
 	  </form>
	  <li><a href="Product Catagory.php">Product Catagory</a></li>
      <li><a href="#">Sales Product</a></li>
	  <li><a href="PopularFlightOffer.html">Sales Report</a></li>
      <li><a href="#">Approve Employee Registration</a></li>
	  <br>
	  
    </ul>
  </nav>
  
  <article>
    
  </article>
</section>









</body>














</html>