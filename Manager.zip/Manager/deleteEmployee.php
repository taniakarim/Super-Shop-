
<!DOCTYPE html>
<html>
    <head>
        <title>project</title>
    </head>
    <body>
	    <h1 style="color:blue;">Delete Employee</h1>
        <form method="post" action="deleteEmployee.php">
            <table>
                <tr>
                    <td>Type Employee Id</td>
                    <td><input type="text" name="empId" required></td>
                </tr>
          
                <td><input type="submit" name="submit_button" value="Delete" required></td>
                </tr>
            </table>
            
            <h5><a href='memberHome.php'>Go back</a></h5>
            
        </form>
    </body>
</html>