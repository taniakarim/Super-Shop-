
<!DOCTYPE html>
<html>
<head>
    <title>Project</title>
	<style>
	
	table{text-align: center;}
	</style>

    </head>
    <body>
        
<h1 style="color:blue;">Employee Salary Bonus</h1>
        <table width="600" border="10" cellpadding="1" cellspacing="1">
   <tr>
      <th>Employee Id</th>
      <th>Salary Bonus</th>
      <th>Payment Date</th>    
    </tr>


	 <tr>
     <td>11210</td>
     <td>20'000</td>
     <td>10-10-2020</td>
     </tr>
	 <tr>
     <td>11212</td>
     <td>25'000</td>
     <td>10-10-2020</td>
     </tr>
	 <tr>
     <td>11217</td>
     <td>30'000</td>
     <td>11-10-2020</td>
     </tr>
	 <tr>
     <td>11215</td>
     <td>28'000</td>
     <td>10-10-2020</td>
     </tr>


	

</table>
  <h5><a href='employeeHome.php'>Go back</a></h5>

</body>
</html
