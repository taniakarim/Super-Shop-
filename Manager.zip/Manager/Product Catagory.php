<!DOCTYPE html>
<html>
    <head>
        <title>Project</title>
    </head>
    <body>
        <h1 style="color:blue;">Product Catagory</h1>
       <section>
  <nav>
   
	  <li><a href="http://kenakatasupershop.com/groceries.html">Groceries</a></li>
      <li><a href="http://kenakatasupershop.com/frozen-food.html">Electronics</a></li>
	  <li><a href="http://kenakatasupershop.com/fruits-vegetable.html">Vegetables & Fruits</a></li>
      <li><a href="http://kenakatasupershop.com/fashion-jewelary-leather.html">Fashion Items</a></li>
	  <br>
	  
    </ul>
  </nav>
  
  <article>
    
  </article>
</section>
    </body>
</html>